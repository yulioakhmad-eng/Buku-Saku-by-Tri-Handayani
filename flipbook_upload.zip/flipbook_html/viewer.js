// viewer.js - simple image flipbook
const book = document.getElementById('book');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');

let current = 1; // left page number (1-based index into pages array)
if(pages.length === 0){
  book.innerHTML = '<div style="padding:20px">Tidak ada halaman</div>';
} else {
  // ensure starting at page 1 (odd index shown left)
  current = 1;
  renderSpread();
}

// render two pages (current and current+1)
function renderSpread(){
  book.innerHTML = '';
  const spread = document.createElement('div');
  spread.className = 'spread';
  // left page
  const leftDiv = document.createElement('div');
  leftDiv.className = 'page';
  const leftImg = document.createElement('img');
  const leftIdx = current - 1;
  leftImg.src = pages[leftIdx] ? pages[leftIdx] : '';
  leftDiv.appendChild(leftImg);
  spread.appendChild(leftDiv);
  // right page
  const rightDiv = document.createElement('div');
  rightDiv.className = 'page';
  const rightImg = document.createElement('img');
  const rightIdx = current;
  rightImg.src = pages[rightIdx] ? pages[rightIdx] : '';
  rightDiv.appendChild(rightImg);
  spread.appendChild(rightDiv);

  book.appendChild(spread);
}

// navigation
function next(){
  if(current + 2 <= pages.length){ current += 2; renderSpread(); }
}
function prev(){
  if(current - 2 >= 1){ current -= 2; renderSpread(); }
}
nextBtn.addEventListener('click', next);
prevBtn.addEventListener('click', prev);

// swipe for mobile
let startX = 0;
book.addEventListener('touchstart', e=> { startX = e.touches[0].clientX; });
book.addEventListener('touchend', e=> {
  const dx = e.changedTouches[0].clientX - startX;
  if(dx < -50) next();
  else if(dx > 50) prev();
});